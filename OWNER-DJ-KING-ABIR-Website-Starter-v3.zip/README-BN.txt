# OWNER DJ KING ABIR — Website starter

## Included
- `index.html`: responsive neon-style Bengali message/caption website.
- `firestore.rules`: starter Firestore rules (not yet deployed).

## Important limitations of this starter
This is a static front-end demo. It works on GitHub Pages, but currently:
- Copy/share/search/view counts are stored in the current visitor's browser only.
- Posts added in the admin demo are stored only in that browser.
- It does NOT yet provide shared/global statistics or cross-device admin publishing.
- The admin password shown in the page is a demo only, NOT secure authentication.

To get global counts and shared posts, connect Firebase Authentication + Cloud Firestore and deploy carefully tested Firestore rules. Never publish private service-account keys. Firebase web config is designed to be public, but database access must be protected by rules and App Check/rate limiting.

## Before publishing
1. Open `index.html` in a text editor.
2. Find `GROUP_URL` and replace `https://t.me/von_mic` with your real Telegram group URL.
3. Find `OWNER_URL` and replace `https://t.me/DJ_ABIR_DEVELOPER_07` with the owner's public Telegram link, e.g. `https://t.me/username`. Do not put a phone number unless you explicitly want it public.
4. Change `ADMIN_DEMO_PASSWORD` only for local demo use; do not treat it as secure.
5. Upload `index.html` to a GitHub repository and enable GitHub Pages from Settings → Pages → Deploy from a branch → main → /(root).

## GitHub Pages
The site will remain hosted while the repository and Pages service remain available and within applicable terms/limits. No service can guarantee "lifetime" uptime.
